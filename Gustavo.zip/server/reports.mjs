// Coletor e interpretador de relatórios vulcânicos (fontes oficiais + notícias).
// Interpretação determinística por regras (sem alucinação); IA opcional via env.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const TTL_OBS = 10 * 60_000;
const TTL_REPORTS = 10 * 60_000;
const TTL_CAT = 12 * 3600e3;
const GNEWS_QS = [
  'volcano eruption', 'Fuego Guatemala volcano', 'Popocatepetl volcano', 'Etna OR Stromboli OR Sheveluch volcano',
  'Sabancaya OR Sangay OR Reventador OR Santiaguito volcano', 'Kilauea volcano', 'Dukono OR Semeru OR Ibu volcano',
  'Sheveluch volcano', 'Stromboli volcano', 'Santiaguito volcano', 'Krakatau OR Anak Krakatau volcano',
];

const mem = new Map(); // cache genérico {t, body}
async function cachedFetch(url, ttl, fetcher) {
  const hit = mem.get(url);
  if (hit && Date.now() - hit.t < ttl) return { body: hit.body, cached: true };
  const body = await fetcher(url);
  mem.set(url, { t: Date.now(), body });
  return { body, cached: false };
}
async function getHTML(url) {
  const r = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'text/html' } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.text();
}
const stripTags = (t) => t.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, ' ').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ').trim();
const norm = (s) => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
/** Tokens normalizados (mantém limites de palavra). */
const words = (s) => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter(Boolean);

/* ============================ Catálogo GVP p/ associação ============================ */
let catalog = null; // { t, list: [{ vn, name, country, words }] }
async function getCatalog() {
  if (catalog && Date.now() - catalog.t < TTL_CAT) return catalog.list;
  const q = 'service=WFS&version=2.0.0&request=GetFeature&outputFormat=application/json&typeNames=GVP-VOTW:E3WebApp_HoloceneVolcanoes&propertyName=VolcanoNumber,VolcanoName,Country&count=2000';
  const r = await fetch(`https://webservices.volcano.si.edu/geoserver/GVP-VOTW/wfs?${q}`, { headers: { 'User-Agent': UA } });
  if (!r.ok) throw new Error(`WFS HTTP ${r.status}`);
  const j = await r.json();
  const list = [];
  const byName = new Map();
  for (const f of j.features ?? []) {
    const p = f.properties || {};
    if (!p.VolcanoName) continue;
    const info = { vn: p.VolcanoNumber, name: p.VolcanoName, country: p.Country || '—', words: words(p.VolcanoName) };
    list.push(info);
    byName.set(norm(p.VolcanoName), info);
  }
  // apelidos (domos complexos / variantes de imprensa)
  const alias = { santiaguito: 'santamaria', santamariadome: 'santamaria', kilauea: 'kilauea' };
  for (const [a, target] of Object.entries(alias)) {
    const hit = byName.get(target);
    if (hit) list.push({ ...hit, words: [a] });
  }
  catalog = { t: Date.now(), list };
  return list;
}
/** Nomes do catálogo que também são palavras comuns em notícias: exigem contexto vulcânico. */
const AMBIGUOUS = new Set([
  'morning', 'late', 'wolf', 'hood', 'ruby', 'brothers', 'fisher', 'baker', 'martin', 'clark',
  'hayes', 'herbert', 'douglas', 'adams', 'santiago', 'granada', 'berlin', 'flores', 'mare',
  'pico', 'tana', 'dana', 'madeira', 'cay', 'agua',
]);
const VOLCANO_CTX = new Set(['volcano', 'volcan', 'volcanes', 'gunung', 'mount', 'vulcao']);
/** Subsequência contígua de palavras (nomes de vulcão são curtos). */
const includesWords = (hay, needle, requireCtx = false) => {
  if (!needle.length) return false;
  for (let i = 0; i + needle.length <= hay.length; i++) {
    let ok = true;
    for (let k = 0; k < needle.length; k++) if (hay[i + k] !== needle[k]) { ok = false; break; }
    if (!ok) continue;
    if (!requireCtx) return true;
    const next = hay[i + needle.length];
    if (next && VOLCANO_CTX.has(next)) return true;
  }
  return false;
};
/** Encontra o vulcão do catálogo num texto (título). */
async function matchVolcano(text) {
  const list = await getCatalog();
  const tw = words(text);
  let best = null;
  for (const info of list) {
    const key = info.words.join(' ');
    if (includesWords(tw, info.words, AMBIGUOUS.has(key)) && (!best || info.words.length > best.words.length)) best = info;
  }
  return best ?? null;
}
/** Todos os vulcões do catálogo mencionados no texto (para títulos com vários nomes). */
export async function matchVolcanoes(text) {
  const list = await getCatalog();
  const tw = words(text);
  const out = [];
  const seenVn = new Set();
  for (const info of list) {
    const key = info.words.join(' ');
    if (includesWords(tw, info.words, AMBIGUOUS.has(key)) && !seenVn.has(info.vn)) { seenVn.add(info.vn); out.push(info); }
  }
  return out;
}

/* ============================ Interpretador (regras, multilíngue) ============================ */
const RULES = [
  ['EXPLOSIVA', /explosiv|eksplosif|explosión|dome collapse|colapso/i],
  ['CINZAS', /\b(ash|cinza|abu vulkanik|ceniza)\b/i],
  ['STROMBOLIANA', /strombol/i],
  ['LAVA', /lava|effusi|efusiv|derrame/i],
  ['PIROCLASTICO', /piroclast|pyroclast|guguran|awan panas|flujo de/i],
  ['LAHAR', /\blahar\b|debris flow|deslizamiento/i],
  ['INCANDESCENCIA', /incandes|glow|panas/i],
  ['SISMICIDADE', /earthquake|volcanic tremor|gempa vulkanik|sismo|terremoto|seismic/i],
  ['GASES', /so2|sulfur dioxide|gas emission|fumarol|emisi gas/i],
  ['ERUPCAO_MODERADA', /moderate.*?(erupt|explosi)|low-level eruption|freatomagmat/i],
  ['INQUIETACAO', /unrest|inquietação|waspada|takut|awas|siaga|advisory/i],
  // ERUPCAO não vem do texto: só de nível de alerta oficial (evita "eruption threat", "no eruption" etc.)
];
const ACTIVE_ERUPTION = /\berupt(?:ion|ive)?\b[^.]{0,80}\b(ongoing|continues|continuing|underway|in progress|began|started|occurring|erupting)\b|\berupting\b|\bfountaining\b/i;
const ERUPTION_GAP = /\beruption\b[^.]{0,50}\b(paused|ended|stopped|ceased|no longer|not occurring)\b|\bno eruption\b/i;
/** Texto oficial descreve erupção em curso (e não pausada/encerrada)? */
const isEruptiveText = (t) => ACTIVE_ERUPTION.test(t) && !ERUPTION_GAP.test(t);
function interpret(text) {
  const t = text || '';
  const cats = RULES.filter(([, re]) => re.test(t)).map(([c]) => c);
  let ashKm = null;
  const m = t.match(/(?:ash|plume|cinza|abu|ceniza)[^.\n]{0,140}?(\d{2,5})\s*(?:m|metros|meters)\b/i)
    || t.match(/(\d{2,5})\s*(?:m|metros|meters)\b[^.\n]{0,80}?(?:above the crater|dari puncak|de altura|acima)/i);
  if (m) ashKm = Math.round((Number(m[1]) / 10)) / 100;
  const erupting = /erupsi|erupción|eruption|letusan/i.test(t);
  return { cats, ashKm, erupting };
}

/* ============================ Coletores ============================ */
export async function getPhivolcs() {
  return cachedFetch('phivolcs', TTL_OBS, async () => {
    const html = await getHTML('https://wovodat.phivolcs.dost.gov.ph/bulletin/list-of-bulletin');
    const plain = stripTags(html);
    const out = { ok: true, levels: {}, bulletins: {}, details: {}, errors: [], items: [] };
    for (const [, name, lvl] of plain.matchAll(/(Taal|Kanlaon|Mayon|Bulusan|Pinatubo)\s*-\s*(\d+)/g)) out.levels[name] = Number(lvl);
    for (const [, name, d] of plain.matchAll(/([A-Za-z-]+)\s+Volcano\s+Summary of 24Hr Observation\s+(\d{1,2}\s+\w+\s+\d{4})/g)) out.bulletins[name] = d;
    const CODE = { mvo: 'Mayon', tvo: 'Taal', kvo: 'Kanlaon', bvo: 'Bulusan', pvo: 'Pinatubo' };
    const bids = {};
    for (const m of html.matchAll(/\/bulletin\/activity-(mvo|tvo|kvo|bvo|pvo)\?bid=(\d+)/g)) if (!bids[m[1]]) bids[m[1]] = Number(m[2]);
    await Promise.all(Object.entries(bids).map(async ([code, bid]) => {
      const name = CODE[code];
      try {
        const r = await fetch(`https://wovodat.phivolcs.dost.gov.ph/bulletin/activity-${code}?bid=${bid}&lang=en`, { headers: { 'User-Agent': UA } });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const text = (await r.text()).replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, '\n').replace(/\n{2,}/g, '\n').split('\n').map((s) => s.trim()).filter(Boolean).join('\n');
        const level = Number(text.match(/ALERT LEVEL\s*\n?\s*(\d)/)?.[1]);
        const date = text.match(/Date:\s*(\d{1,2}\s+\w+\s+\d{4})/)?.[1];
        const desc = text.match(/\(([^)]+)\)\s*\n?\s*ALERT LEVEL/)?.[1];
        const eqs = text.match(/(\d+)\s*\nvolcanic earthquakes/)?.[0].replace('\n', ' ');
        const so2 = text.match(/Sulfur Dioxide Flux\s*\n([^\n]+)/)?.[1];
        const plume = text.match(/Plume\s*\n([^\n]+)/)?.[1];
        if (level != null) out.levels[name] = level;
        if (date) out.bulletins[name] = date;
        const det = {};
        if (desc) det.desc = desc; if (eqs) det.eqs = eqs; if (so2) det.so2 = so2; if (plume) det.plume = plume;
        if (Object.keys(det).length) out.details[name] = det;
        const interpretado = interpret(text.replace(/PHIVOLCS-LAVA:\s*/g, ''));
        // erupção confirmada = nível de alerta oficial (PHIVOLCS ≥3); o texto só complementa as demais categorias
        interpretado.cats = interpretado.cats.filter((c) => c !== 'ERUPCAO');
        if (level >= 3) interpretado.cats.unshift('ERUPCAO');
        const vol = await matchVolcano(`${name} volcano philippines`);
        if (vol && date) out.items.push({
          id: `phivolcs-${bid}`, ts: Date.parse(date) || Date.now(), date, source: 'PHIVOLCS', kind: 'OFICIAL', verified: 'CONFIRMADO',
          title: `${name} Volcano Bulletin — Alert Level ${level ?? '?'}`, url: `https://wovodat.phivolcs.dost.gov.ph/bulletin/activity-${code}?bid=${bid}&lang=en`,
          volcanoVn: vol.vn, volcanoName: vol.name, country: vol.country,
          text: [det.eqs, det.so2 ? 'SO₂: ' + det.so2 : null, det.plume].filter(Boolean).join(' · ') || text.slice(0, 300),
          cats: interpretado.cats, ashKm: interpretado.ashKm, period: '24h',
        });
      } catch (e) { out.errors.push(`${name}: ${e.message || e}`); }
    }));
    return out;
  });
}

export async function getPvmbg() {
  return cachedFetch('pvmbg', TTL_OBS, async () => {
    const [tingkat, laporan] = await Promise.all([
      getHTML('https://magma.esdm.go.id/v1/gunung-api/tingkat-aktivitas'),
      getHTML('https://magma.esdm.go.id/v1/gunung-api/laporan'),
    ]);
    const text = tingkat.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, '|').replace(/\|+/g, '|').replace(/\s+/g, ' ');
    const base = text.indexOf('Daftar Tingkat Aktivitas');
    const detail = base >= 0 ? text.slice(base) : text;
    const marks = ['Level IV (Awas)', 'Level III (Siaga)', 'Level II (Waspada)', 'Level I (Normal)'].map((m) => ({ m, i: detail.indexOf(m) })).filter((x) => x.i >= 0).sort((a, b) => a.i - b.i);
    const out = { ok: true, levels: {}, items: [], errors: [] };
    marks.forEach((cur, k) => {
      const level = Number(cur.m.match(/Level (IV|III|II)/)?.[1].replace('IV', '4').replace('III', '3').replace('II', '2')) || 0;
      const seg = detail.slice(cur.i + cur.m.length, k + 1 < marks.length ? marks[k + 1].i : undefined);
      for (const m2 of seg.matchAll(/([A-Z\u00C0-\u00FA][A-Za-z\u00C0-\u00FA'()\.\- ]{2,40}?) - [^|]+/g)) {
        const name = m2[1].trim();
        if (name && !/^(Level|Hasil|Tidak|yaitu Gunung)$/.test(name)) out.levels[name] = level;
      }
    });
    // relatórios diários descritivos (laporan)
    const lt = laporan.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, '|').replace(/\|+/g, '|').replace(/(\|\s*\|)+/g, '|').replace(/\s+/g, ' ');
    const MONTHS = { Januari: '01', Februari: '02', Maret: '03', April: '04', Mei: '05', Juni: '06', Juli: '07', Agustus: '08', September: '09', Oktober: '10', November: '11', Desember: '12' };
    const rows = [...lt.matchAll(/\|\s*([A-Z\u00C0-\u00FA][^|]{1,38})(?:\s*\|)+\s*(Level [IVX]+ \([^)]+\))[\s\S]{0,140}?-\s*([A-Za-z]+),\s*(\d{1,2})\s+(\w+)\s+(\d{4})(?:\s*\|)+\s*([^|]{20,600})/g)];
    for (const m of rows.slice(0, 40)) {
      const name = m[1].trim(), level = m[2], iso = `${m[6]}-${MONTHS[m[5]] || '01'}-${String(m[4]).padStart(2, '0')}`;
      const desc = m[7].trim();
      const vol = await matchVolcano(name + ' gunung api indonesia');
      if (!vol) continue;
      const ip = interpret(desc);
      ip.cats = ip.cats.filter((c) => c !== 'ERUPCAO');
      if (/Level (IV|III)/.test(level)) ip.cats.unshift('ERUPCAO');
      out.items.push({
        id: `pvmbg-${norm(vol.name)}-${iso}-${norm(String(desc).slice(0, 20))}`, ts: Date.parse(iso) || Date.now(), date: iso,
        source: 'PVMBG', kind: 'OFICIAL', verified: 'CONFIRMADO', title: `${vol.name} — Laporan Aktivitas (${level})`,
        url: 'https://magma.esdm.go.id/v1/gunung-api/laporan', volcanoVn: vol.vn, volcanoName: vol.name, country: vol.country,
        text: desc, cats: ip.cats, ashKm: ip.ashKm, period: m[0].match(/Periode [\d:\- ]+WI[BTA]/)?.[0],
      });
    }
    return out;
  });
}

export async function getUsgs() {
  return cachedFetch('usgs', TTL_OBS, async () => {
    const r = await fetch('https://volcanoes.usgs.gov/hans-public/api/volcano/getElevatedVolcanoes', { headers: { 'User-Agent': UA } });
    if (!r.ok) throw new Error(`HANS HTTP ${r.status}`);
    const list = await r.json();
    const out = { ok: true, levels: {}, items: [], errors: [] };
    const elev = (list ?? []).slice(0, 12);
    await Promise.all(elev.map(async (v) => {
      const vn = Number(v.vnum);
      if (vn) out.levels[`${v.volcano_name}`] = { vn, level: v.alert_level, color: v.color_code, sent: v.sent_utc };
      try {
        const r2 = await fetch(`https://volcanoes.usgs.gov/hans-public/api/volcano/newestForVolcano/${vn}`, { headers: { 'User-Agent': UA } });
        if (!r2.ok) throw new Error(`HTTP ${r2.status}`);
        const j = await r2.json();
        const text = stripTags(String(j.noticeHtml || ''));
        const sent = j.sentUtc || v.sent_utc;
        const vol = await matchVolcano(`${v.volcano_name} united states volcano`);
        if (!vol) return;
        const ip = interpret(text);
        if (/warning/i.test(String(v.alert_level)) || /red/i.test(String(v.color_code)) || isEruptiveText(text)) ip.cats.unshift('ERUPCAO');
        out.items.push({
          id: `usgs-${j.noticeId || vn}-${String(sent).slice(0, 10)}`, ts: Date.parse(String(sent).replace(' ', 'T') + 'Z') || Date.now(),
          date: sent, source: 'USGS', kind: 'OFICIAL', verified: 'CONFIRMADO', title: j.noticeTitle || `${v.volcano_name} update`,
          url: j.noticeUrl || 'https://volcanoes.usgs.gov/', volcanoVn: vol.vn, volcanoName: vol.name, country: vol.country,
          text: text.slice(0, 500), cats: ip.cats, ashKm: ip.ashKm,
          period: `${v.alert_level} ${v.color_code}`,
        });
      } catch (e) { out.errors.push(`${v.volcano_name}: ${e.message || e}`); }
    }));
    return out;
  });
}

/** Veículos sem verificação editorial conhecida → NÃO CONFIRMADO. */
const SOCIAL_SRC = /facebook|blogspot|blog|youtube|reddit|twitter|x\.com/i;

export async function getNews() {
  return cachedFetch('news', TTL_OBS, async () => {
    const items = [];
    const seen = new Set();
    const MONTHS = { Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06', Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12' };
    for (const q of GNEWS_QS) {
      try {
        const xml = await getHTML(`https://news.google.com/rss/search?q=${encodeURIComponent(q + ' when:2d')}&hl=en-US&gl=US&ceid=US:en`);
        for (const it of xml.matchAll(/<item>[\s\S]*?<\/item>/g)) {
          const title = /<title>([^<]+)<\/title>/.exec(it[0])?.[1];
          const date = /<pubDate>([^<]+)<\/pubDate>/.exec(it[0])?.[1];
          const link = /<link>([^<]+)<\/link>/.exec(it[0])?.[1];
          const src = /<source[^>]*>([^<]+)<\/source>/.exec(it[0])?.[1] || 'Google News';
          if (!title || !date || !link) continue;
          // "Título - Veículo": o veículo não deve gerar uma segunda notícia
          const key = norm(title.replace(/\s+[-–—]\s+[^-]{2,40}$/, '')).slice(0, 60);
          const isWorldwide = /volcanic activity worldwide/i.test(title);
          const firstTime = !seen.has(key);
          seen.add(key);
          const mm = date.match(/, (\d{1,2}) (\w{3}) (\d{4})/);
          const iso = mm ? `${mm[3]}-${MONTHS[mm[2]] || '01'}-${String(mm[1]).padStart(2, '0')}` : null;
          const vols = await matchVolcanoes(title);
          // Resumos mundiais ("Volcanic activity worldwide…") têm o título truncado: completa
          // com os vulcões nomeados na consulta que os encontrou (todos citados na edição).
          if (isWorldwide) {
            for (const cand of q.split(/\s+OR\s+/i)) {
              const hint = cand.replace(/\s*volcano\s*$/i, '').trim();
              const hit = hint ? await matchVolcano(hint) : null;
              if (hit && !vols.some((v) => v.vn === hit.vn)) vols.push(hit);
            }
          }
          const ip = interpret(title);
          const base = {
            ts: Date.parse(date) || Date.now(), date: iso || date, source: src, kind: 'NOTICIA',
            verified: SOCIAL_SRC.test(src) ? 'NAO_CONFIRMADO' : 'REPORTADO',
            title, url: link, text: title, cats: ip.cats, ashKm: ip.ashKm,
          };
          if (vols.length) {
            if (!firstTime && !isWorldwide) continue;
            for (const vol of vols) {
              const id = `news-${key}-${vol.vn}`;
              if (items.some((x) => x.id === id)) continue;
              items.push({ ...base, id, volcanoVn: vol.vn, volcanoName: vol.name, country: vol.country });
            }
          } else {
            if (!firstTime) continue;
            items.push({ ...base, id: `news-${key}`, volcanoVn: null, volcanoName: null, country: null });
          }
        }
      } catch (e) { items.push({ id: 'err-' + norm(q), error: String(e.message || e) }); }
    }
    // NASA Earth Observatory (RSS oficial; filtra itens vulcânicos)
    try {
      const xml = await getHTML('https://earthobservatory.nasa.gov/feeds/natural-hazards.rss');
      for (const it of xml.matchAll(/<item>[\s\S]*?<\/item>/g)) {
        const title = /<title>([^<]+)<\/title>/.exec(it[0])?.[1];
        if (!title || !/volcan/i.test(title)) continue;
        const date = /<pubDate>([^<]+)<\/pubDate>/.exec(it[0])?.[1];
        const link = /<link>([^<]+)<\/link>/.exec(it[0])?.[1];
        const desc = stripTags(/<description>[\s\S]*?<\/description>/.exec(it[0])?.[0] || '');
        const vol = await matchVolcano(title + ' ' + desc.slice(0, 200));
        const ip = interpret(title + ' ' + desc);
        items.push({
          id: `eo-${norm(title)}`, ts: Date.parse(date || '') || Date.now(), date: date?.slice(0, 16) || null,
          source: 'NASA Earth Observatory', kind: 'NOTICIA', verified: 'REPORTADO', title, url: link || 'https://earthobservatory.nasa.gov/',
          volcanoVn: vol?.vn ?? null, volcanoName: vol?.name ?? null, country: vol?.country ?? null,
          text: desc.slice(0, 400), cats: ip.cats, ashKm: ip.ashKm,
        });
      }
    } catch (e) { items.push({ id: 'err-eo', error: String(e.message || e) }); }
    return { ok: true, items };
  });
}

/* ============================ Persistência + agregação ============================ */
const DATA_FILE = join(__dirname, 'data', 'reports.json');
function loadStore() { try { return existsSync(DATA_FILE) ? JSON.parse(readFileSync(DATA_FILE, 'utf8')) : { items: [], lastStamp: null }; } catch { return { items: [], lastStamp: null }; } }
function saveStore(store) { try { mkdirSync(join(__dirname, 'data'), { recursive: true }); writeFileSync(DATA_FILE, JSON.stringify(store)); } catch { /* disco cheio etc. */ } }

let agg = null; // { t, out }
export async function getReports(force = false) {
  if (!force && agg && Date.now() - agg.t < TTL_REPORTS) return agg.out;
  const [ph, pv, us, news] = await Promise.allSettled([getPhivolcs(), getPvmbg(), getUsgs(), getNews()]);
  const get = (r) => (r.status === 'fulfilled' ? (r.value?.body ?? r.value) : { ok: false, items: [], errors: [String(r.reason?.message ?? r.reason)] });
  const phv = get(ph), pvg = get(pv), usg = get(us), nws = get(news);
  const fresh = [...phv.items ?? [], ...pvg.items ?? [], ...usg.items ?? [], ...nws.items ?? []].filter((x) => !x.error);
  const store = loadStore();
  // Reinterpreta itens antigos com as regras atuais (texto não confirma erupção).
  for (const it of store.items) {
    if (it.kind === 'NOTICIA') {
      const ip = interpret(String(it.title));
      it.cats = ip.cats;
      if (ip.ashKm) it.ashKm = ip.ashKm;
      it.verified = SOCIAL_SRC.test(String(it.source || '')) ? 'NAO_CONFIRMADO' : 'REPORTADO';
    } else if (it.source === 'USGS') {
      const eruptive = /warning|red/i.test(String(it.period || '')) || isEruptiveText(String(it.text || ''));
      it.cats = (it.cats || []).filter((c) => c !== 'ERUPCAO');
      if (eruptive) it.cats.unshift('ERUPCAO');
    }
  }
  // Repara atribuições antigas feitas por nomes ambíguos do catálogo (ex.: "Morning").
  if (store.items.some((i) => i.kind === 'NOTICIA' && i.volcanoName && AMBIGUOUS.has(String(i.volcanoName).toLowerCase()))) {
    for (const it of store.items) {
      if (it.kind !== 'NOTICIA' || !it.volcanoName) continue;
      if (!AMBIGUOUS.has(String(it.volcanoName).toLowerCase())) continue;
      const vols = await matchVolcanoes(it.title);
      const v = vols[0];
      it.volcanoVn = v?.vn ?? null; it.volcanoName = v?.name ?? null; it.country = v?.country ?? null;
      if (v) it.id = `news-${norm(it.title).slice(0, 60)}-${v.vn}`;
    }
    const seenIds = new Set();
    store.items = store.items.filter((i) => (seenIds.has(i.id) ? false : (seenIds.add(i.id), true)));
    saveStore(store);
  }
  const seen = new Set(store.items.map((i) => i.id));
  let added = 0;
  for (const it of fresh) if (!seen.has(it.id)) { store.items.push(it); seen.add(it.id); added++; }
  store.items.sort((a, b) => b.ts - a.ts);
  if (store.items.length > 3000) store.items.length = 3000;
  if (added || !store.lastStamp) { store.lastStamp = new Date().toISOString(); saveStore(store); }

  const winRaw = store.items.filter((i) => Date.now() - i.ts < 48 * 3600e3);
  // dedupe de notícias: mesmo título (sem o sufixo " - veículo") + mesmo vulcão
  const newsKey = (i) => `${i.volcanoVn ?? 'x'}|${norm(String(i.title).replace(/\s+[-–—]\s+[^-]{2,40}$/, '')).slice(0, 80)}`;
  const seenNews = new Set();
  const win = winRaw.filter((i) => {
    if (i.kind !== 'NOTICIA') return true;
    const k = newsKey(i);
    if (seenNews.has(k)) return false;
    seenNews.add(k);
    return true;
  });
  const sources = [
    { id: 'phivolcs', label: 'PHIVOLCS', ok: phv.ok, stamp: Date.now(), errors: phv.errors ?? [] },
    { id: 'pvmbg', label: 'PVMBG', ok: pvg.ok, stamp: Date.now(), errors: pvg.errors ?? [] },
    { id: 'usgs', label: 'USGS HANS', ok: usg.ok, stamp: Date.now(), errors: usg.errors ?? [] },
    { id: 'gnews', label: 'Notícias (Google News: Reuters/AP/etc.)', ok: nws.ok, stamp: Date.now(), errors: [] },
    { id: 'eo', label: 'NASA Earth Observatory', ok: nws.ok, stamp: Date.now(), errors: [] },
    { id: 'gvp', label: 'GVP relatórios HTML', ok: false, stamp: Date.now(), errors: ['indisponível server-side (desafio anti-bot F5, HTTP 403); o catálogo WFS do GVP é usado normalmente'] },
  ];
  const erupting = [...new Set(win.filter((i) => i.kind === 'OFICIAL' && i.cats.includes('ERUPCAO')).map((i) => i.volcanoName).filter(Boolean))];
  const byCat = {};
  for (const c of ['EXPLOSIVA', 'CINZAS', 'STROMBOLIANA', 'LAVA', 'PIROCLASTICO', 'LAHAR', 'GASES', 'SISMICIDADE', 'INQUIETACAO']) {
    const names = [...new Set(win.filter((i) => i.cats.includes(c)).map((i) => i.volcanoName).filter(Boolean))];
    if (names.length) byCat[c] = names;
  }
  const ash = win.filter((i) => i.ashKm && i.volcanoName).map((i) => `${i.volcanoName}: coluna ~${i.ashKm.toFixed(1)} km`);
  const out = {
    ok: true,
    stamp: new Date().toISOString(),
    total: store.items.length,
    window48: win.length,
    added,
    erupting,
    byCat,
    ash,
    panorama: await buildPanorama(win, { erupting, byCat, ash, sources }),
    sources,
    items: win.slice(0, 150),
  };
  agg = { t: Date.now(), out };
  return out;
}

/* ============================ Panorama (determinístico + IA opcional) ============================ */
async function buildPanorama(win, { erupting, byCat, ash, sources }) {
  const now = new Date();
  const base = {
    gerado: now.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }),
    oficials: win.filter((i) => i.kind === 'OFICIAL').length,
    noticias: win.filter((i) => i.kind === 'NOTICIA').length,
    erupting, byCat, ash,
  };
  // IA opcional (endpoint OpenAI-compatible via env). Sem config → texto determinístico.
  const { AI_API_URL, AI_API_KEY, AI_MODEL } = process.env;
  if (AI_API_URL && AI_API_KEY) {
    try {
      const facts = JSON.stringify({
        gerado: base.gerado,
        janela_horas: 48,
        erupcoes_confirmadas: erupting,
        atividade_por_categoria: byCat,
        colunas_de_cinzas_km: ash,
        amostra_relatorios: win.filter((i) => i.kind === 'OFICIAL').slice(0, 25).map((i) => ({ vulcao: i.volcanoName, pais: i.country, data: i.date, texto: i.text.slice(0, 160) })),
      });
      const r = await fetch(`${AI_API_URL.replace(/\/$/, '')}/chat/completions`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${AI_API_KEY}` },
        body: JSON.stringify({
          model: AI_MODEL || 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'Você é analista vulcanológico. Escreva um panorama mundial em português do Brasil (1 parágrafo) usando EXCLUSIVAMENTE os dados JSON fornecidos. Não invente vulcões, números, datas ou eventos. Diferencie erupção contínua, episódio isolado e inquietação. Cite apenas vulcões presentes nos dados.' },
            { role: 'user', content: facts },
          ],
          temperature: 0.2,
        }),
      });
      if (r.ok) {
        const j = await r.json();
        const txt = j?.choices?.[0]?.message?.content;
        if (txt) return { ai: true, ...base, text: String(txt).trim() };
      }
    } catch { /* cai no determinístico */ }
  }
  const fmt = (arr) => arr?.length ? arr.join(', ') : null;
  const parts = [];
  parts.push(`Erupções confirmadas em boletins oficiais nas últimas 48 horas: ${erupting.length ? erupting.join(', ') + '.' : 'nenhuma até o momento.'}`);
  if (byCat.EXPLOSIVA) parts.push(`Foram registrados episódios explosivos envolvendo: ${fmt(byCat.EXPLOSIVA)}.`);
  if (byCat.CINZAS) parts.push(`Emissões de cinzas: ${fmt(byCat.CINZAS)}.`);
  if (byCat.STROMBOLIANA) parts.push(`Atividade stromboliana: ${fmt(byCat.STROMBOLIANA)}.`);
  if (byCat.LAVA) parts.push(`Lava/extrusão: ${fmt(byCat.LAVA)}.`);
  if (byCat.PIROCLASTICO) parts.push(`Fluxos piroclásticos: ${fmt(byCat.PIROCLASTICO)}.`);
  if (ash.length) parts.push(`Colunas de cinzas medidas: ${ash.join('; ')}.`);
  const unrest = byCat.INQUIETACAO?.filter((n) => !erupting.includes(n));
  if (unrest?.length) parts.push(`Também em inquietação vulcânica: ${fmt(unrest)}.`);
  if (byCat.SISMICIDADE) parts.push(`Sismicidade vulcânica destacada em: ${fmt(byCat.SISMICIDADE)}.`);
  parts.push(`Fontes analisadas: ${sources.filter((s) => s.ok).map((s) => s.label).join('; ')} (${base.oficials} relatórios oficiais e ${base.noticias} notícias em 48 h).`);
  return { ai: false, ...base, text: parts.join(' ') };
}
