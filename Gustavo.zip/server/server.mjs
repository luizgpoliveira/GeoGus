// Proxy + servidor estático para o TerraPulse (sem dependências externas).
// O GVP (webservices.volcano.si.edu) não envia cabeçalhos CORS, então o frontend
// consome o catálogo do Smithsonian exclusivamente via /api/gvp com cache em memória.
import http from 'node:http';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { extname, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { getPhivolcs, getPvmbg, getReports } from './reports.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DIST = join(__dirname, '..', 'dist');
const BASE = 'https://webservices.volcano.si.edu/geoserver/GVP-VOTW/wfs';
const PORT = Number(process.env.PORT || 8787);
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

const cache = new Map(); // q -> { t, status, ct, body }
const TTL_ERUP = 10 * 60_000;   // erupções em curso: 10 min
const TTL_LOCAL = 6 * 3600e3;   // detalhes por vulcão: 6 h
const TTL_CAT = 12 * 3600e3;    // catálogos completos: 12 h

const TTL_OBS = 15 * 60_000;    // observatórios nacionais: 15 min
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2',
};

function ttlFor(q) {
  if (q.includes('ContinuingEruption')) return TTL_ERUP;
  if (/VolcanoNumber%3D|%3D\d{6}/.test(q)) return TTL_LOCAL;
  return TTL_CAT;
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const url = new URL(req.url, `http://localhost:${PORT}`);

  if (url.pathname === '/api/gvp' || url.pathname === '/api/gvp/') {
    const q = url.searchParams.get('q') || '';
    if (!q) { res.writeHead(400); return res.end('missing q'); }
    const key = q;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.t < ttlFor(key)) {
      res.writeHead(200, { 'Content-Type': hit.ct, 'X-Cache': 'HIT', 'X-Cache-Age': String(Math.round((Date.now() - hit.t) / 1000)) });
      return res.end(hit.body);
    }
    try {
      const target = `${BASE}?${q}`;
      const r = await fetch(target, { headers: { 'User-Agent': 'TerraPulse/1.0 (monitoring app)' } });
      const body = Buffer.from(await r.arrayBuffer());
      if (!r.ok) { res.writeHead(r.status, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: `GVP ${r.status}` })); }
      cache.set(key, { t: Date.now(), ct: 'application/json; charset=utf-8', body });
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'X-Cache': 'MISS' });
      res.end(body);
    } catch (e) {
      const stale = cache.get(key);
      if (stale) { res.writeHead(200, { 'Content-Type': 'application/json', 'X-Cache': 'STALE' }); return res.end(stale.body); }
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: String(e) }));
    }
    return;
  }

  // Observatórios nacionais + central de relatórios (coleta/interpretação em reports.mjs).
  const json = (data, status = 200) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); };
  // limite de espera: fonte lenta responde erro em vez de deixar o cliente pendurado
  const cap = (p, ms, label) => Promise.race([
    p,
    new Promise((_, rej) => setTimeout(() => rej(new Error(`${label} excedeu ${Math.round(ms / 1000)}s`)), ms).unref?.()),
  ]);
  try {
    if (url.pathname === '/api/phivolcs') {
      const data = await cap(getPhivolcs(), 20_000, 'PHIVOLCS');
      return json({ ...data.body, stamp: new Date().toISOString() });
    }
    if (url.pathname === '/api/pvmbg') {
      const data = await cap(getPvmbg(), 20_000, 'PVMBG');
      return json({ ...data.body, stamp: new Date().toISOString() });
    }
    if (url.pathname === '/api/reports') {
      const force = url.searchParams.get('force') === '1';
      return json(await getReports(force));
    }
  } catch (e) {
    return json({ ok: false, error: String(e?.message || e) });
  }

  // estático (dist)
  let p = join(DIST, decodeURIComponent(url.pathname));
  if (!existsSync(p) || statSync(p).isDirectory()) p = join(DIST, 'index.html');
  const ext = extname(p);
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
  res.end(readFileSync(p));
});

server.listen(PORT, () => console.log(`TerraPulse server em http://localhost:${PORT}`));
