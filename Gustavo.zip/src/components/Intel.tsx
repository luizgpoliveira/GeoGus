import { useMemo, useState } from 'react';
import type { ReportItem, ReportsPayload, Volcano } from '../types';
import { useI18n } from '../i18n';
import VolcanoPhoto from './VolcanoPhoto';

const fmtDT = (ts: number, locale: string) =>
  new Date(ts).toLocaleString(locale, { dateStyle: 'short', timeStyle: 'short' });

const CAT_ORDER = ['ERUPCAO', 'EXPLOSIVA', 'CINZAS', 'ERUPCAO_MODERADA', 'STROMBOLIANA', 'LAVA', 'PIROCLASTICO', 'LAHAR', 'INCANDESCENCIA', 'SISMICIDADE', 'GASES', 'INQUIETACAO'];

interface IntelProps {
  reports: ReportsPayload | null;
  volcanoes: Volcano[];
  onLocate: (vn: number) => void;
}

/** Cards consolidados por vulcão a partir dos relatórios (oficiais primeiro). */
function buildCards(items: ReportItem[], volcanoes: Volcano[]) {
  const byVn = new Map<number, { items: ReportItem[] }>();
  for (const it of items) {
    if (!it.volcanoVn) continue;
    const g = byVn.get(it.volcanoVn) ?? { items: [] };
    g.items.push(it);
    byVn.set(it.volcanoVn, g);
  }
  const out = [] as Array<{
    vn: number; name: string; country: string; latest: ReportItem; official: ReportItem | null;
    cats: string[]; volcano: Volcano | undefined;
  }>;
  for (const [vn, g] of byVn) {
    const sorted = [...g.items].sort((a, b) => b.ts - a.ts);
    const official = sorted.find((x) => x.kind === 'OFICIAL') ?? null;
    const latest = official ?? sorted[0];
    const cats = [...new Set(sorted.flatMap((x) => x.cats))].filter((c) => CAT_ORDER.includes(c));
    out.push({
      vn,
      name: latest.volcanoName || `vn ${vn}`,
      country: latest.country || '—',
      latest, official, cats,
      volcano: volcanoes.find((v) => v.vn === vn),
    });
  }
  // erupção primeiro, depois atividade oficial recente, depois notícias
  const w = (c: typeof out[number]) => (c.volcano?.status === 'ERUPCAO' ? 0 : c.official ? 1 : 2);
  return out.sort((a, b) => w(a) - w(b) || b.latest.ts - a.latest.ts);
}

export default function Intel({ reports, volcanoes, onLocate }: IntelProps) {
  const { t, locale } = useI18n();
  const [open, setOpen] = useState(true);
  const cards = useMemo(() => (reports ? buildCards(reports.items, volcanoes) : []), [reports, volcanoes]);
  const pano = reports?.panorama;

  return (
    <section className={`intel ${open ? 'open' : ''}`}>
      <div className="intel-head">
        <button className="intel-toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
          <span className="intel-dot" /> {t('intel.title')}
          <span className="intel-count">{cards.length}</span>
          <span className="intel-chev">{open ? '▾' : '▸'}</span>
        </button>
        {pano && (
          <span className="intel-stamp muted small">
            {t('intel.updated', { time: fmtDT(Date.parse(reports!.stamp) || Date.now(), locale) })}
            {' · '}{pano.oficials} {t('updates.official').toLowerCase()} + {pano.noticias} {t('updates.news').toLowerCase()}
            {pano.ai ? ' · IA' : ''}
          </span>
        )}
      </div>
      {open && (
        <div className="intel-body">
          {!reports && <p className="muted small">{t('intel.noData')}</p>}
          {reports && (
            <>
              <p className="intel-text">{pano?.text}</p>
              <div className="intel-sources">
                <span className="muted small">{t('intel.sources')}:</span>
                {reports.sources.map((s) => (
                  <span key={s.id} className={`chip ${s.ok ? 'ok' : 'err'}`} title={(s.errors || []).join('; ') || s.label}>
                    {s.label.split(' (')[0]}
                  </span>
                ))}
              </div>
              {cards.length > 0 && (
                <>
                  <div className="intel-sub">{t('intel.cards')} ({cards.length})</div>
                  <div className="intel-cards">
                    {cards.slice(0, 12).map((c) => {
                      const status = c.volcano?.status;
                      const alert = c.volcano?.alertInfo;
                      const cats = c.cats.slice(0, 4);
                      return (
                        <article key={c.vn} className={`icard ${status === 'ERUPCAO' ? 'erupting' : ''}`}>
                          <div className="icard-photo">
                            <VolcanoPhoto vn={c.vn} name={c.name} gvpFile={c.volcano?.image?.file} />
                          </div>
                          <div className="icard-body">
                            <h4>{c.name} <span className="icard-country">{c.country}</span></h4>
                            <div className="icard-status">
                              {status && <span className={`badge ${status === 'ERUPCAO' ? 'live' : 'status'}`}>{t(`status.${status}`)}</span>}
                              {alert && (
                                <span className="icard-alert">{alert.source} · {String(alert.level)}{alert.colorCode ? ` · ${alert.colorCode}` : ''}</span>
                              )}
                            </div>
                            {cats.length > 0 && (
                              <div className="icard-cats">{cats.map((k) => <span key={k} className={`tag cat-${k}`}>{t(`cat.${k}` as any)}</span>)}</div>
                            )}
                            <p className="icard-sum"><span className="muted small">{t('intel.lastEvent')}: </span>{String(c.latest.title)}</p>
                            {c.latest.text && c.latest.text !== c.latest.title && (
                              <p className="icard-text">{String(c.latest.text).slice(0, 180)}</p>
                            )}
                            <div className="icard-meta">
                              <span className={`kind ${c.latest.kind === 'OFICIAL' ? 'oficial' : 'noticia'}`}>
                                {c.latest.kind === 'OFICIAL' ? t('updates.official') : t('updates.news')}
                              </span>
                              {' '}{c.latest.source} · {c.latest.date ? String(c.latest.date) : fmtDT(c.latest.ts, locale)}
                            </div>
                            <div className="icard-actions">
                              <button className="btn" onClick={() => onLocate(c.vn)}>{t('intel.locate')}</button>
                              {c.latest.url && <a className="btn ghost" href={c.latest.url} target="_blank" rel="noopener noreferrer">{t('pp.more')}</a>}
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </>
              )}
            </>
          )}
        </div>
      )}
    </section>
  );
}

interface UpdatesProps {
  items: ReportItem[];
  onLocate: (vn: number) => void;
  onOpen?: (vn: number) => void;
}

/** Lista ATUALIZAÇÕES (aba da sidebar): relatórios oficiais e notícias, com filtro. */
export function UpdatesList({ items, onLocate, onOpen }: UpdatesProps) {
  const { t, locale } = useI18n();
  const [onlyOfficial, setOnlyOfficial] = useState(false);
  const list = (onlyOfficial ? items.filter((i) => i.kind === 'OFICIAL') : items).slice(0, 120);

  return (
    <div className="updates">
      <div className="updates-bar">
        <b>{t('updates.title')}</b>
        <label className="chk">
          <input type="checkbox" checked={onlyOfficial} onChange={(e) => setOnlyOfficial(e.target.checked)} /> {t('updates.officialOnly')}
        </label>
      </div>
      {list.length === 0 && <p className="empty">{t('updates.empty')}</p>}
      <ul className="upd-list">
        {list.map((it) => (
          <li key={it.id} className={`upd ${it.kind === 'OFICIAL' ? 'oficial' : 'noticia'}`}>
            <div className="upd-head">
              <span className={`kind ${it.kind === 'OFICIAL' ? 'oficial' : 'noticia'}`}>
                {it.kind === 'OFICIAL' ? t('updates.official') : t('updates.news')}
              </span>
              <span className={`verif ${it.verified === 'CONFIRMADO' ? 'ok' : it.verified === 'NAO_CONFIRMADO' ? 'bad' : 'warn'}`}>
                {it.verified === 'CONFIRMADO' ? t('updates.confirmed') : it.verified === 'NAO_CONFIRMADO' ? t('updates.unconfirmed') : t('updates.reported')}
              </span>
              <span className="upd-date">{it.date ? String(it.date) : fmtDT(it.ts, locale)}</span>
            </div>
            <div className="upd-title">{String(it.title)}</div>
            {it.volcanoName && (
              <div className="upd-volcano">
                <button className="linklike" onClick={() => { if (it.volcanoVn) onLocate(it.volcanoVn); onOpen?.(it.volcanoVn ?? -1); }}>
                  {it.volcanoName}{it.country ? ` · ${it.country}` : ''}
                </button>
              </div>
            )}
            {it.period && <div className="upd-period muted small">{t('updates.period')}: {String(it.period)}</div>}
            {it.text && it.text !== it.title && <p className="upd-text">{String(it.text).slice(0, 400)}</p>}
            {it.cats.length > 0 && (
              <div className="icard-cats">{it.cats.slice(0, 4).map((k) => <span key={k} className={`tag cat-${k}`}>{t(`cat.${k}` as any)}</span>)}</div>
            )}
            <div className="upd-foot">
              <span className="muted small">{it.source}</span>
              {it.url && <a className="linklike" href={it.url} target="_blank" rel="noopener noreferrer">{t('pp.more')}</a>}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
